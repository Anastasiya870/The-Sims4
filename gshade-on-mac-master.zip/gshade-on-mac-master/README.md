# gshade on mac

A simple utility to install gshade into CrossOver Bottles.

### How to use

Open Terminal and copy/paste the following command
```
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/ZoeyCluff/gshade-on-mac/master/Gshade_on_mac.sh)"
```
