// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
    apiKey: "AIzaSyDJc3IfKrImz-2HwrIeF1tMugfMO6XKcfs",
    authDomain: "sims4-cheatcodes.firebaseapp.com",
    projectId: "sims4-cheatcodes",
    storageBucket: "sims4-cheatcodes.appspot.com",
    messagingSenderId: "613933431000",
    appId: "1:613933431000:web:b91cc699055850e783bfad",
    measurementId: "G-66BZFYT93R"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();